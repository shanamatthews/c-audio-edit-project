int parseAIFFFile(FILE* file);

int swap(char toSwap[256], int swap1, int swap2);

int getNumSamples();
int getNumChannels();
int getBitDepth();
long double getFileRate();
