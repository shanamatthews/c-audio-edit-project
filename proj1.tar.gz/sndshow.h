int main(int argc, char *argv[]);

int printCS229Show(FILE *file, int channelToShow, int width, int zoom, int bitDepth, int channels, int samples);

char* makeString(int width, int bitDepth, int dataPoint);

void displayShowHelp();
