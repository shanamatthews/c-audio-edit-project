int main(int argc, char *argv[]); 

void displayInfoHelp();

int openFile();

int openMultipleFiles(int numFiles, char *fileNames[]);