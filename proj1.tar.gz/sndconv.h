int main(); 

void displayConvHelp();

int promptForFiles();